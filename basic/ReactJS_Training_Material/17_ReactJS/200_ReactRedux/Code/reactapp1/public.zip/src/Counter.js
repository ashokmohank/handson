import React from 'react';

class Counter extends React.Component {

  constructor() {
    super();

    this.state = {
      count: 0,
    };

    this.handleClick = this
      .handleClick
      .bind(this);

    this.handleClick2 = this
      .handleClick2
      .bind(this);
  }

  handleClick(ev) {
    this.setState({
      count: this.state.count + 1,
    });

    /* this.setState((prevState, props) => ({
      count: prevState.count + 1,
    })); */

    ev.preventDefault();
  }

  handleClick2(ev) {
    this.setState({
      count: this.state.count + 2,
    });

    /* this.setState((prevState, props) => ({
      count: prevState.count + 2,
    })); */

    ev.preventDefault();
  }

  render() {
    return (
      <div>
        <Form handler1={this.handleClick} handler2={this.handleClick2} />

        <Display content={this.state.count} />
      </div>
    );
  }
}

const Display = props => <h2>{props.content}</h2>;

class Form extends React.Component {

  render() {
    return (
      <form action="">
        <button onClick={this.props.handler1}>Increment</button>
        &nbsp;&nbsp;&nbsp;&nbsp;

        <button onClick={this.props.handler2}>Increment 2</button>
      </form>
    );
  }
}

export default Counter;
