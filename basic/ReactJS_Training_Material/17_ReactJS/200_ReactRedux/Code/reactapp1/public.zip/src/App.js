import React from 'react';

class App extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      counter: this.props.start,
    };

    this.handleIncrement = this
      .handleIncrement
      .bind(this);

    this.handleDecrement = this
      .handleDecrement
      .bind(this);
  }

  handleIncrement(ev) {
    ev.preventDefault();

    this.setState((prevState, props) => ({
      counter: prevState.counter + this.props.step,
    }));
  }

  handleDecrement(ev) {
    ev.preventDefault();

    this.setState((prevState, props) => ({
      counter: prevState.counter - this.props.step,
    }));
  }

  render() {
    return (
      <div>
        <h1>My Counter:</h1>
        <h3>{this.state.counter}</h3>

        <form action="">
          <button onClick={this.handleIncrement}>Increment</button>

          &nbsp;&nbsp;

          <button onClick={this.handleDecrement}>Decrement</button>
        </form>

      </div>
    );
  }
}

export default App;
