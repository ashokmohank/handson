import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

ReactDOM.render(
  <App start={500} step={25} />, document.getElementById('root'));
